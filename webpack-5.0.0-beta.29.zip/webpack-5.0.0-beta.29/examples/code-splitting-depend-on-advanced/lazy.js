import lodash from "lodash";
import propTypes from "prop-types";

console.log(lodash, propTypes);
