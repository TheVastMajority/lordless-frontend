# example.js

```javascript
_{{example.js}}_
```

# fs.js

```javascript
_{{fs.js}}_
```

# reexport-commonjs.js

```javascript
_{{reexport-commonjs.js}}_
```

# example2.js

```javascript
_{{example2.js}}_
```

# harmony.js

```javascript
_{{harmony.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
