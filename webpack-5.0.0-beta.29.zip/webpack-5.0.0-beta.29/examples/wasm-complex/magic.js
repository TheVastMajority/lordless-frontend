// reexporting
export * from "./magic.wat";
