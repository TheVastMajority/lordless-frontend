# example.js

```javascript
_{{example.js}}_
```

# magic.js

```javascript
_{{magic.js}}_
```

# magic.wat

```wat
_{{magic.wat}}_
```

# magic-number.js

```javascript
_{{magic-number.js}}_
```

# memory.js

```javascript
_{{memory.js}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
