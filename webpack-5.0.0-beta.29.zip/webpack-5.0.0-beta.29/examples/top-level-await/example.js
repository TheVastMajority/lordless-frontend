import { CreateUserAction } from "./Actions.js";

(async ()=> {
	await CreateUserAction("John");
})();
