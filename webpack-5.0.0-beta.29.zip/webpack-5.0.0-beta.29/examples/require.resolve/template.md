# example.js

``` javascript
_{{example.js}}_
```

# a.js


``` javascript
_{{a.js}}_
```

# dist/output.js

``` javascript
_{{dist/output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
