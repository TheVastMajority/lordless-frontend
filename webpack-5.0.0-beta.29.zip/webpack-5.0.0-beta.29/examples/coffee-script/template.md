# example.js

```javascript
_{{example.js}}_
```

# cup1.coffee

```coffee-script
_{{cup1.coffee}}_
```

# cup2.coffee

```coffee-script
_{{cup2.coffee}}_
```

# dist/output.js

```javascript
_{{dist/output.js}}_
```

# Info

## Unoptimized

```
_{{stdout}}_
```

## Production mode

```
_{{production:stdout}}_
```
