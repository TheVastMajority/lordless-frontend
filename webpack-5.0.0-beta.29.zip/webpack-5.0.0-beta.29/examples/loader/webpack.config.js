module.exports = {
	// mode: "development || "production",
	module: {
		rules: [
			{
				test: /\.css$/,
				loader: "css-loader"
			}
		]
	}
};
