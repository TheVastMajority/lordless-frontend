var baz = "baz";

export default baz;
